<footer class="footer-premium text-white">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4">
                <div class="footer-logo mb-4">{{ config('app.name') }}<span class="text-info-ppi">.</span></div>
                <p class="text-light opacity-75 pe-lg-5">A leading organization dedicated to identifying and nurturing youth talents through technology and strong leadership. We are the bridge to your success.</p>
                <div class="mt-4">
                    <a href="javascript:void(0)" class="social-circle shadow-sm">FB</a>
                    <a href="javascript:void(0)" class="social-circle shadow-sm">IG</a>
                    <a href="javascript:void(0)" class="social-circle shadow-sm">X</a>
                    <a href="javascript:void(0)" class="social-circle shadow-sm">IN</a>
                </div>
            </div>

            <div class="col-lg-2 col-6">
                <h5 class="fw-bold mb-4 text-white">Quick Links</h5>
                <a href="javascript:void(0)" class="footer-link">About Us</a>
                <a href="javascript:void(0)" class="footer-link">Our Projects</a>
                <a href="javascript:void(0)" class="footer-link">Volunteer</a>
                <a href="javascript:void(0)" class="footer-link">Contact Us</a>
            </div>

            <div class="col-lg-2 col-6">
                <h5 class="fw-bold mb-4 text-white">Programs</h5>
                <a href="javascript:void(0)" class="footer-link">Coding for Kids</a>
                <a href="javascript:void(0)" class="footer-link">Leadership Club</a>
                <a href="javascript:void(0)" class="footer-link">Talent Scouting</a>
                <a href="javascript:void(0)" class="footer-link">Digital Literacy</a>
            </div>

            <div class="col-lg-4">
                <h5 class="fw-bold mb-4 text-white">Get In Touch</h5>
                <div class="contact-pill shadow-sm">
                    <span class="material-symbols-outlined text-info-ppi" style="font-size: 28px;">mail</span>
                    <div>
                        <small class="text-light opacity-50 d-block">Email us at:</small>
                        <span class="fw-bold">{{ config('app.ppi_email') }}</span>
                    </div>
                </div>
                <div class="contact-pill shadow-sm">
                    <span class="material-symbols-outlined text-info-ppi" style="font-size: 28px;">call</span>
                    <div>
                        <small class="text-light opacity-50 d-block">Helpline:</small>
                        <span class="fw-bold">{{ config('app.ppi_phone_number') }}</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="border-top border-secondary mt-5 pt-4 pb-4">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <p class="small text-light opacity-50 mb-0">&copy; 2026 Potential Pioneer Initiatives. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="javascript:void(0)" class="text-light opacity-50 small text-decoration-none me-3 hover-info">Privacy Policy</a>
                    <a href="javascript:void(0)" class="text-light opacity-50 small text-decoration-none hover-info">Terms of Service</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="modal fade" id="welcomeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 glass-modal shadow-lg">
            <div class="modal-header border-0 pb-0">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-5 pt-2">
                <div class="modal-icon-wrapper mb-4">
                    <span class="material-symbols-outlined text-info-ppi" style="font-size: 60px;">rocket_launch</span>
                </div>
                <h2 class="fw-bold mb-3">Welcome to <span class="text-info-ppi">PPI</span></h2>
                <p class="text-muted lead mb-4">
                    We are a bridge to success for young people. We help nurture talents, technology (Coding), and leadership to build a better tomorrow.
                </p>
                <div class="d-grid gap-2">
                    <button class="btn btn-info-ppi btn-lg rounded-pill" data-bs-dismiss="modal">Discover More</button>
                    <a href="javascript:void(0)" class="btn btn-link text-decoration-none text-muted">Maybe later</a>
                </div>
            </div>
        </div>
    </div>
</div>

<a href="javascript:void(0)" class="sticky-support animate-bounce shadow-lg" data-bs-toggle="modal" data-bs-target="#supportModal" title="Support PPI">
    <div class="support-text shadow">Support Our Mission</div>
    <div class="support-icon">
        <span class="material-symbols-outlined" style="font-size: 30px;">volunteer_activism</span>
    </div>
</a>
