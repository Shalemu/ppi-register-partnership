
<nav class="navbar navbar-expand-lg sticky-top">
 <div class="d-flex align-items-center">
    <a href="{{ url('/') }}">
        <img src="{{ asset('assets/images/ppi-logo.png') }}" 
             alt="PPI Logo"
             class="navbar-logo">
    </a>
</div>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="material-symbols-outlined">menu</span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link" href="{{ url('/') }}">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#ourMission">Our Mission</a></li>
                <li class="nav-item"><a class="nav-link" href="#ourTeam">Our Team</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Programs</a></li>
                <li class="nav-item"><a class="nav-link" href="#LatestNews">Latest News</a></li>
                <li class="nav-item ms-lg-4">
                    <a href="#" class="btn btn-info-ppi animate-bounce shadow-lg" data-bs-toggle="modal" data-bs-target="#supportModal" title="Support PPI">
                        Support The Movement
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<style>
    .navbar-logo {
    height: 60px;
    width: auto;
    margin-left: 30px;
}

@media (max-width: 768px) {
    .navbar-logo {
        height: 34px;
    }
}
</style>
