
<!DOCTYPE html>
<html lang="sw">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PPI | Potential Pioneer Initiatives</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="{{ asset('assets/css/style.css')}}" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bolder" href="#">PPI<span>.</span></a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="material-symbols-outlined">menu</span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link" href="{{ url('/') }}">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#ourMission">Our Mission</a></li>
                <li class="nav-item"><a class="nav-link" href="#ourTeam">Our Team</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Programs</a></li>
                <li class="nav-item"><a class="nav-link" href="#LatestNews">Latest News</a></li>
                <li class="nav-item ms-lg-4">
                    <a href="#" class="btn btn-info-ppi animate-bounce shadow-lg" data-bs-toggle="modal" data-bs-target="#supportModal" title="Support PPI">
                        Support The Movement
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

@include('includes.partials.alerts')
@yield('content')

<footer class="footer-premium text-white">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4">
                <div class="footer-logo mb-4">PPI<span class="text-info-ppi">.</span></div>
                <p class="text-muted pe-lg-5">Taasisi inayoongoza kwa kuibua na kulea vipaji vya vijana kupitia teknolojia na uongozi bora. Sisi ni daraja la mafanikio yako.</p>
                <div class="mt-4">
                    <a href="#" class="social-circle">FB</a>
                    <a href="#" class="social-circle">IG</a>
                    <a href="#" class="social-circle">X</a>
                    <a href="#" class="social-circle">IN</a>
                </div>
            </div>

            <div class="col-lg-2 col-6">
                <h5 class="fw-bold mb-4">Quick Links</h5>
                <a href="#" class="footer-link">About Us</a>
                <a href="#" class="footer-link">Our Projects</a>
                <a href="#" class="footer-link">Volunteer</a>
                <a href="#" class="footer-link">Contact Us</a>
            </div>

            <div class="col-lg-2 col-6">
                <h5 class="fw-bold mb-4">Programs</h5>
                <a href="#" class="footer-link">Coding for Kids</a>
                <a href="#" class="footer-link">Leadership Club</a>
                <a href="#" class="footer-link">Talent Scouting</a>
                <a href="#" class="footer-link">Digital Literacy</a>
            </div>

            <div class="col-lg-4">
                <h5 class="fw-bold mb-4">Get In Touch</h5>
                <div class="contact-pill">
                    <span class="material-symbols-outlined text-info-ppi">mail</span>
                    <div>
                        <small class="text-muted d-block">Email us at:</small>
                        <span class="fw-bold">{{ config('app.ppi_email') }}</span>
                    </div>
                </div>
                <div class="contact-pill">
                    <span class="material-symbols-outlined text-info-ppi">call</span>
                    <div>
                        <small class="text-muted d-block">Helpline:</small>
                        <span class="fw-bold">{{ config('app.ppi_phone_number') }}</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="border-top border-secondary mt-5 pt-4 pb-4">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <p class="small text-muted mb-0">&copy; 2026 Potential Pioneer Initiatives. Haki zote zimehifadhiwa.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-muted small text-decoration-none me-3">Privacy Policy</a>
                    <a href="#" class="text-muted small text-decoration-none">Terms of Service</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="modal fade" id="welcomeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 glass-modal shadow-lg">
            <div class="modal-header border-0 pb-0">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-5 pt-2">
                <div class="modal-icon-wrapper mb-4">
                    <span class="material-symbols-outlined text-info-ppi" style="font-size: 60px;">rocket_launch</span>
                </div>
                <h2 class="fw-bold mb-3">Karibu <span class="text-info-ppi">PPI</span></h2>
                <p class="text-muted lead mb-4">
                    Sisi ni daraja la mafanikio kwa vijana. Tunasaidia kukuza vipaji, teknolojia (Coding), na uongozi ili kujenga kesho iliyo bora.
                </p>
                <div class="d-grid gap-2">
                    <button class="btn btn-info-ppi btn-lg rounded-pill" data-bs-dismiss="modal">Gundua Zaidi</button>
                    <a href="#" class="btn btn-link text-decoration-none text-muted">Labda baadae</a>
                </div>
            </div>
        </div>
    </div>
</div>

<a href="#" class="sticky-support animate-bounce shadow-lg" data-bs-toggle="modal" data-bs-target="#supportModal" title="Support PPI">
    <div class="support-text shadow">Support Our Mission</div>
    <div class="support-icon">
        <span class="material-symbols-outlined" style="font-size: 30px;">volunteer_activism</span>
    </div>
</a>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('assets/js.scripts.js') }}"></script>
</body>
</html>
