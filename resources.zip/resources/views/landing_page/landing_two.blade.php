@extends('layouts.app')

@section('content')
    @include('landing_page.partials.banner_slider')


    <section class="py-5" style="margin-top: -50px;">
        <div class="container" id="ourMission">
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="glass-card p-4 text-center shadow-sm bg-white">
                        <h2 class="fw-bold text-info-ppi">500+</h2>
                        <p class="text-muted mb-0">Youth Impacted</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="glass-card p-4 text-center shadow-sm bg-white">
                        <h2 class="fw-bold text-info-ppi">12+</h2>
                        <p class="text-muted mb-0">Active Programs</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="glass-card p-4 text-center shadow-sm bg-white">
                        <h2 class="fw-bold text-info-ppi">15+</h2>
                        <p class="text-muted mb-0">Expert Mentors</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="glass-card p-4 text-center shadow-sm bg-white">
                        <h2 class="fw-bold text-info-ppi">100%</h2>
                        <p class="text-muted mb-0">Dedication</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5 bg-light">
        <div class="container">
            <div class="row align-items-center mb-5">
                <div class="col-md-6">
                    <h6 class="text-info-ppi fw-bold text-uppercase">What We Do</h6>
                    <h2 class="display-5 fw-bold">Innovative Programs for <span class="text-gradient">Impact</span></h2>
                </div>
                <div class="col-md-6">
                    <p class="text-muted">PPI hutoa elimu isiyo rasmi inayojikita katika kuibua kile ambacho shule za kawaida hazikioni. Kutoka Coding hadi Uongozi.</p>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                        <div class="icon-box mb-4 text-info-ppi">
                            <span class="material-symbols-outlined style="font-size: 50px;">terminal</span>
                        </div>
                        <h4 class="fw-bold">Coding for Kids</h4>
                        <p class="text-muted">Kufundisha watoto lugha ya kesho. Tunawapa ujuzi wa kutatua matatizo kwa kutumia teknolojia.</p>
                        <a href="#" class="text-info-ppi text-decoration-none fw-bold mt-auto">Learn More →</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                        <div class="icon-box mb-4 text-info-ppi">
                            <span class="material-symbols-outlined" style="font-size: 50px;">psychology</span>
                        </div>
                        <h4 class="fw-bold">The Power In Me</h4>
                        <p class="text-muted">Programu ya kisaikolojia na uongozi inayolenga kujenga kujiamini na kutambua thamani ya ndani.</p>
                        <a href="#" class="text-info-ppi text-decoration-none fw-bold mt-auto">Learn More →</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                        <div class="icon-box mb-4 text-info-ppi">
                            <span class="material-symbols-outlined" style="font-size: 50px;">theater_comedy</span>
                        </div>
                        <h4 class="fw-bold">Talent & Leadership</h4>
                        <p class="text-muted">Kukuza sanaa, michezo na uwezo wa kuongoza jamii kupitia vipaji vya asili.</p>
                        <a href="#" class="text-info-ppi text-decoration-none fw-bold mt-auto">Learn More →</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @include('landing_page.partials.ppi_programs')
    @include('landing_page.partials.ppi_team')
    @include('landing_page.partials.news_and_events')
    @include('landing_page.partials.call_to_action')

    @include('landing_page.partials.modal')
@endsection
