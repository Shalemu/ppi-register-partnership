<section class="hero-wrapper-full">

    <div class="hero-full">

        <!-- Background -->
        <div class="hero-bg"
            style="background-image: url('{{ asset('/assets/images/events/bg.jpeg') }}');">
        </div>

        <!-- Dark Overlay -->
        <div class="hero-overlay"></div>

        <!-- Center Content -->
        <div class="hero-content-box text-center text-white">

            <span class="hero-subtitle">FUTURE LEADERS HUB</span>

            <h1>
                Unlocking <span class="text-accent">Potential</span><br>
                Inspiring Purpose
            </h1>

            <p>
               We believe every young person carries within them endless potential we simply help them discover it.
            </p>

            <div class="hero-buttons">
                <a href="#" class="btn btn-primary-hero">Join Programs</a>
                <a href="#" class="btn btn-outline-hero">Contact Us</a>
            </div>

        </div>

        <!-- Floating Bottom Box --> 
    </div>

</section>

<style>
/* ===============================
   FULL WIDTH HERO
=================================*/

.hero-wrapper-full {
    position: relative;
}

.hero-full {
    position: relative;
    width: 100%;
    min-height: 90vh;
    overflow: hidden;
}

/* Background */
.hero-bg {
    position: absolute;
    inset: 0;
    background-size: cover;
    background-position: center;
    animation: zoomBg 18s ease-in-out infinite alternate;
}

@keyframes zoomBg {
    0% { transform: scale(1); }
    100% { transform: scale(1.06); }
}

/* Overlay */
.hero-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.7);
}

/* Content */
.hero-content-box {
    position: relative;
    z-index: 2;
    padding: 120px 20px 160px;
    max-width: 900px;
    margin: auto;
}

.hero-subtitle {
    display: inline-block;
    background: rgba(255,255,255,0.1);
    padding: 6px 18px;
    border-radius: 30px;
    font-size: 13px;
    letter-spacing: 1px;
    margin-bottom: 20px;
}

.hero-content-box h1 {
    font-size: clamp(3rem, 5vw, 4.8rem);
    font-weight: 800;
    line-height: 1.15;
    margin-bottom: 20px;
}

.hero-content-box p {
    opacity: 0.85;
    font-size: 22px;
    margin-bottom: 35px;
}

/* Accent */
.text-accent {
    color: #0096c7;
}

/* Buttons */
.hero-buttons {
    display: flex;
    justify-content: center;
    gap: 15px;
    flex-wrap: wrap;
}

.btn-primary-hero {
    background: #0096c7;
    color: #fff;
    padding: 14px 32px;
    border-radius: 8px;   /* Reduced radius */
    font-weight: 600;
    border: none;
    transition: 0.3s ease;
}

.btn-primary-hero:hover {
    background: #e56700;
    transform: translateY(-3px);
}

.btn-outline-hero {
    border: 1.5px solid #fff;
    padding: 14px 30px;
    border-radius: 8px;   /* Reduced radius */
    color: #fff;
    transition: 0.3s ease;
}

.btn-outline-hero:hover {
    background: #fff;
    color: #000;
}

/* Floating Bottom Box */
.hero-search-box {
    position: absolute;
    bottom: -50px;
    left: 50%;
    transform: translateX(-50%);
    background: #fff;
    border-radius: 15px;
    padding: 25px;
    display: flex;
    gap: 20px;
    box-shadow: 0 25px 50px rgba(0,0,0,0.2);
    z-index: 3;
    width: 92%;
    max-width: 1100px;
}

.search-item {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.search-item label {
    font-size: 12px;
    margin-bottom: 5px;
    color: #777;
}

.search-item select {
    border: 1px solid #ddd;
    padding: 10px;
    border-radius: 8px;
}

.search-btn {
    display: flex;
    align-items: end;
}

.search-btn button {
    width: 100%;
    background: #ff7a00;
    color: #fff;
    border: none;
    padding: 12px;
    border-radius: 8px;
}

/* Mobile */
@media (max-width: 768px) {

    .hero-content-box {
        padding: 100px 20px 140px;
    }

    .hero-search-box {
        flex-direction: column;
        bottom: -120px;
        gap: 15px;
    }

    .hero-buttons {
        flex-direction: column;
        align-items: center;
    }

    .btn-primary-hero,
    .btn-outline-hero {
        width: 100%;
        max-width: 260px;
    }
}
</style>