@push('styles')
    <style>
        .bg-soft-dark {
            background-color: #0b1120; /* Dark Navy Blue */
            background-image: radial-gradient(circle at 50% 50%, #111a2e 0%, #0b1120 100%);
            position: relative;
            overflow: hidden;
        }

        .bg-pattern-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: radial-gradient(rgba(13, 202, 240, 0.05) 1px, transparent 1px);
            background-size: 30px 30px;
            opacity: 0.5;
            pointer-events: none;
        }

        .program-card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 40px 35px;
            border-radius: 30px;
            transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
            height: 100%;
            color: white;
            display: flex;
            flex-direction: column;
        }

        .program-card:hover {
            background: #ffffff;
            transform: translateY(-12px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            border-color: var(--ppi-info);
        }

        .program-card:hover h4,
        .program-card:hover p,
        .program-card:hover ul li,
        .program-card:hover .material-symbols-outlined {
            color: #212529 !important;
        }

        .program-card h4 {
            font-weight: 800;
            margin-bottom: 15px;
            transition: color 0.3s;
        }

        .program-card p {
            color: #cbd5e0;
            font-size: 0.95rem;
            line-height: 1.6;
            transition: color 0.3s;
        }

        .program-icon-box {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white !important;
            margin-bottom: 25px;
        }

        .bg-gradient-ppi {
            background: linear-gradient(45deg, #0dcaf0, #0077b6);
        }

        .border-top-info {
            border-top: 4px solid var(--ppi-info) !important;
        }

        .program-link {
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            margin-top: auto;
        }

        .program-link:hover {
            letter-spacing: 0.5px;
            color: #0077b6 !important;
        }

        html {
            scroll-behavior: smooth;
        }
    </style>
@endpush

<section id="programs-section" class="py-5 position-relative overflow-hidden bg-soft-dark">
    <div class="bg-pattern-overlay"></div>

    <div class="container py-5 position-relative">
        <div class="text-center mb-5">
            <span class="badge rounded-pill bg-info-ppi mb-3 px-3 py-2 text-uppercase">Our Programmes</span>
            <h2 class="display-5 fw-bold text-white">Nurturing Excellence through <span class="text-info-ppi">Programs</span></h2>
            <p class="text-light opacity-75 mx-auto" style="max-width: 600px;">We offer specialized hubs designed to bridge the gap between talent and professional success.</p>
        </div>

        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="program-card">
                    <div class="program-icon-box bg-info-ppi shadow-sm">
                        <span class="material-symbols-outlined">code</span>
                    </div>
                    <h4>Coding & Tech</h4>
                    <p>Equipping children with future-proof skills in software development and digital logic.</p>
                    <hr class="opacity-10">
                    <ul class="list-unstyled mb-4">
                        <li><i class="material-symbols-outlined fs-6 align-middle text-info-ppi me-2">check_circle</i>Web Development</li>
                        <li><i class="material-symbols-outlined fs-6 align-middle text-info-ppi me-2">check_circle</i>Critical Thinking</li>
                    </ul>
                    <a href="#" class="program-link text-info-ppi text-decoration-none fw-bold d-inline-flex align-items-center">
                        Learn More <span class="material-symbols-outlined ms-1 fs-6">arrow_forward</span>
                    </a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="program-card">
                    <div class="program-icon-box bg-dark shadow-sm">
                        <span class="material-symbols-outlined">leaderboard</span>
                    </div>
                    <h4>Leadership Hub</h4>
                    <p>Developing character, emotional intelligence, and public speaking in young minds.</p>
                    <hr class="opacity-10">
                    <ul class="list-unstyled mb-4">
                        <li><i class="material-symbols-outlined fs-6 align-middle text-info-ppi me-2">check_circle</i>Public Speaking</li>
                        <li><i class="material-symbols-outlined fs-6 align-middle text-info-ppi me-2">check_circle</i>Team Management</li>
                    </ul>
                    <a href="#" class="program-link text-info-ppi text-decoration-none fw-bold d-inline-flex align-items-center">
                        Learn More <span class="material-symbols-outlined ms-1 fs-6">arrow_forward</span>
                    </a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="program-card border-top-info">
                    <div class="program-icon-box bg-gradient-ppi shadow-sm">
                        <span class="material-symbols-outlined">psychology</span>
                    </div>
                    <h4>Talent Mentorship</h4>
                    <p>Personalized guidance to help youth identify and polish their natural-born talents.</p>
                    <hr class="opacity-10">
                    <ul class="list-unstyled mb-4">
                        <li><i class="material-symbols-outlined fs-6 align-middle text-info-ppi me-2">check_circle</i>Career Pathing</li>
                        <li><i class="material-symbols-outlined fs-6 align-middle text-info-ppi me-2">check_circle</i>Soft Skills Training</li>
                    </ul>
                    <a href="#" class="program-link text-info-ppi text-decoration-none fw-bold d-inline-flex align-items-center">
                        Learn More <span class="material-symbols-outlined ms-1 fs-6">arrow_forward</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
