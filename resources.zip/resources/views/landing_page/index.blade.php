@extends('layouts.guest.app')

@section('content')
    @include('landing_page.partials.banner_slider')

    <!-- COUNTERS SECTION -->
    <section class="py-5">
        <div class="container" id="ourMission">
            <div class="row g-4 text-center">
                <div class="col-md-3">
                    <div class="glass-card p-4 shadow-sm bg-white">
                        <h2 class="display-6 fw-bold text-info-ppi mb-1">
                            <span class="counter" data-target="500">0</span>+
                        </h2>
                        <p class="text-muted mb-0">Youth Impacted</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="glass-card p-4 shadow-sm bg-white">
                        <h2 class="display-6 fw-bold text-info-ppi mb-1">
                            <span class="counter" data-target="12">0</span>+
                        </h2>
                        <p class="text-muted mb-0">Active Programs</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="glass-card p-4 shadow-sm bg-white">
                        <h2 class="display-6 fw-bold text-info-ppi mb-1">
                            <span class="counter" data-target="15">0</span>+
                        </h2>
                        <p class="text-muted mb-0">Expert Mentors</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="glass-card p-4 shadow-sm bg-white">
                        <h2 class="display-6 fw-bold text-info-ppi mb-1">
                            <span class="counter" data-target="100">0</span>+
                        </h2>
                        <p class="text-muted mb-0">Dedication</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ABOUT SECTION -->
    <section class="about-premium py-5 position-relative overflow-hidden">
        <div class="container py-5">
            <div class="row align-items-center g-5">

                <!-- LEFT CONTENT -->
                <div class="col-lg-6">
                    <h2 class="fw-bold display-5 mb-4">
                        Unlocking Potential. <span class="text-gradient">Building Future Leaders.</span>
                    </h2>

                    <p class="lead text-muted mb-4">
                        <strong>Potential Pioneers Initiatives (PPI)</strong> is a Non-Governmental Organization (NGO) registered under Act No. 24 of 2002 with the registration number <strong>00NGO/R/8334</strong>.
                    </p>

                    <p class="text-muted mb-4">
                        We empower children and youth in Tanzania by unlocking their potential, promoting structured talent development, and nurturing purposeful living. We believe that every young person carries unique abilities that, when properly identified and developed, can translate into lifelong impact.
                    </p>

                    <div class="about-highlight p-4 mb-4">
                        🧭 We are building a generation of young pioneers ready to lead, innovate, and transform their communities.
                    </div>

                    <a href="#" class="btn btn-premium px-5 py-3 rounded-2 text-white">
                        Read More About Us
                    </a>
                </div>

                <!-- RIGHT VISUAL CARD -->
                <div class="col-lg-6">
                    <div class="about-card shadow-lg p-5 text-center">
                        <div class="icon-circle mb-4">
                            <span class="material-symbols-outlined">rocket_launch</span>
                        </div>
                        <h4 class="fw-bold mb-3">Structured Talent Development</h4>
                        <p class="text-muted">
                            Through mentorship, leadership programs, and digital skills training, we create a strong foundation for youth excellence and national impact.
                        </p>
                    </div>
                </div>

            </div>
        </div>

        <!-- Decorative Background Shape -->
        <div class="about-shape"></div>
    </section>

    <!-- OBJECTIVES SECTION -->
    <section class="objectives-projects py-5">
    <div class="container">
        <div class="objectives-row d-flex flex-wrap flex-lg-nowrap align-items-stretch">

            <!-- LEFT IMAGE -->
            <div class="objectives-col flex-fill">
                <div class="objectives-image-wrapper">
                    <img src="assets/images/objective.jpeg" alt="Youth Empowerment">
                </div>
            </div>

            <!-- RIGHT CONTENT -->
            <div class="objectives-col flex-fill">
                <div class="objectives-content">
                    <h2 class="section-title mb-4">OUR OBJECTIVES</h2>
                    <ul class="objectives-list list-unstyled">
                        <li>
                            <span class="objective-icon"><i class="fas fa-bolt"></i></span>
                            Empower youth & children to solve challenges facing society through their unique talents.
                        </li>
                        <li>
                            <span class="objective-icon"><i class="fas fa-lightbulb"></i></span>
                            Identify and describe opportunities within talents to enhance employability.
                        </li>
                        <li>
                            <span class="objective-icon"><i class="fas fa-book"></i></span>
                            Educate communities on socio-economic issues tied to talent development.
                        </li>
                        <li>
                            <span class="objective-icon"><i class="fas fa-compass"></i></span>
                            Develop youth and children’s talents through training, exposure, and networking.
                        </li>
                        <li>
                            <span class="objective-icon"><i class="fas fa-comments"></i></span>
                            Foster self-awareness and independence among youth and children.
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="projects-section py-5">
    <div class="container">
        <!-- Section Header -->
        <div class="row mb-5 text-center">
            <div class="col-lg-12">
                <h2 class="section-title fw-bold mb-3">
                    OUR PROJECTS <small class="text-muted">Miradi Yetu Inayoendelea</small>
                </h2>
                <p class="lead text-muted">Transforming lives through purpose-driven projects.</p>
            </div>
        </div>

        <!-- Projects Cards -->
        <div class="row g-4 justify-content-center">
            <!-- Project 1 -->
            <div class="col-lg-4 col-md-6">
                <div class="project-card p-4 shadow-lg h-100 rounded-4 d-flex flex-column">
                    <div class="project-icon mb-3">
                        <span class="material-symbols-outlined">psychology</span>
                    </div>
                    <h4 class="fw-bold mb-2">The Power in Me</h4>
                    <p class="text-muted flex-grow-1">
                        A self-awareness and leadership program that helps young people discover who they are, build confidence, and lead positive change in their communities.
                    </p>
                    <span class="project-focus mb-3">Focus: Leadership, Personal Growth</span>
                    <a href="#" class="btn btn-outline-primary mt-auto rounded-pill text-uppercase fw-bold">
                        Explore this Program →
                    </a>
                </div>
            </div>

            <!-- Project 2 -->
            <div class="col-lg-4 col-md-6">
                <div class="project-card p-4 shadow-lg h-100 rounded-4 d-flex flex-column">
                    <div class="project-icon mb-3">
                        <span class="material-symbols-outlined">favorite</span>
                    </div>
                    <h4 class="fw-bold mb-2">Love Destination</h4>
                    <p class="text-muted flex-grow-1">
                        A mentorship and relationship-building initiative promoting healthy values, empathy, and emotional intelligence among youth.
                    </p>
                    <span class="project-focus mb-3">Focus: Emotional Wellness, Mentorship</span>
                    <a href="#" class="btn btn-outline-primary mt-auto rounded-pill text-uppercase fw-bold">
                        Join the Journey →
                    </a>
                </div>
            </div>

            <!-- Project 3 -->
            <div class="col-lg-4 col-md-6">
                <div class="project-card p-4 shadow-lg h-100 rounded-4 d-flex flex-column">
                    <div class="project-icon mb-3">
                        <span class="material-symbols-outlined">terminal</span>
                    </div>
                    <h4 class="fw-bold mb-2">Coding for Kids</h4>
                    <p class="text-muted flex-grow-1">
                        A fun, creative, and educational program introducing children to technology, problem-solving, and coding inspiring the next generation of tech innovators.
                    </p>
                    <span class="project-focus mb-3">Focus: Digital Skills, Innovation</span>
                    <a href="#" class="btn btn-outline-primary mt-auto rounded-pill text-uppercase fw-bold">
                        See How It Works →
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- PROGRAMS SECTION -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row align-items-center mb-5 g-4">
                <div class="col-md-6">
                    <h6 class="text-info-ppi fw-bold text-uppercase">What We Do</h6>
                    <h2 class="display-5 fw-bold">Innovative Programs for <span class="text-gradient">Impact</span></h2>
                </div>
                <div class="col-md-6">
                    <p class="text-muted">PPI provides informal education focused on discovering what traditional schools often overlook. From Coding to Leadership.</p>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                        <div class="icon-box mb-4 text-info-ppi">
                            <span class="material-symbols-outlined" style="font-size:50px;">terminal</span>
                        </div>
                        <h4 class="fw-bold">Coding for Kids</h4>
                        <p class="text-muted">Teaching children the language of the future. We equip them with problem-solving skills through technology.</p>
                        <a href="#" class="text-info-ppi text-decoration-none fw-bold mt-auto d-block">Learn More →</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                        <div class="icon-box mb-4 text-info-ppi">
                            <span class="material-symbols-outlined" style="font-size:50px;">psychology</span>
                        </div>
                        <h4 class="fw-bold">The Power In Me</h4>
                        <p class="text-muted">A psychological and leadership program aimed at building self-confidence and recognizing inner value.</p>
                        <a href="#" class="text-info-ppi text-decoration-none fw-bold mt-auto d-block">Learn More →</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                        <div class="icon-box mb-4 text-info-ppi">
                            <span class="material-symbols-outlined" style="font-size:50px;">theater_comedy</span>
                        </div>
                        <h4 class="fw-bold">Talent & Leadership</h4>
                        <p class="text-muted">Developing arts, sports, and community leadership skills through natural talents.</p>
                        <a href="#" class="text-info-ppi text-decoration-none fw-bold mt-auto d-block">Learn More →</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @include('landing_page.partials.ppi_programs')
    @include('landing_page.partials.ppi_team')
    @include('landing_page.partials.news_and_events')
    @include('landing_page.partials.call_to_action')
    @include('landing_page.partials.modal')
@endsection

<style>
    /* ==========================
   GLOBAL STYLING
========================== */
body {
    line-height: 1.6;
}

/* GRADIENT TEXT */
.text-gradient {
    background: linear-gradient(45deg, #00b4d8, #0077b6);
    -webkit-text-fill-color: transparent;
}

/* ==========================
   ABOUT SECTION
========================== */
.about-premium {
    background: linear-gradient(180deg, #f8fbff, #ffffff);
    position: relative;
    padding-top: 60px;
    padding-bottom: 60px;
}

.about-highlight {
    background: rgba(0,119,182,0.08);
    border-left: 4px solid #0077b6;
    border-radius: 6px;
    font-weight: 500;
}

.btn-premium {
    background: linear-gradient(45deg, #00b4d8, #0077b6);
    color: #fff;
    font-weight: 600;
    border: none;
    transition: all 0.3s ease;
}

.btn-premium:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0,119,182,0.3);
    color: #fff;
}

.about-card {
    background: #fff;
    border-radius: 25px;
    transition: 0.3s ease;
}

.about-card:hover {
    transform: translateY(-6px);
}

.icon-circle {
    width: 80px;
    height: 80px;
    margin: auto;
    border-radius: 50%;
    background: linear-gradient(45deg, #00b4d8, #0077b6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 36px;
}

.about-shape {
    position: absolute;
    top: -80px;
    right: -80px;
    width: 250px;
    height: 250px;
    background: rgba(0,180,216,0.08);
    border-radius: 50%;
}

/* OBJECTIVES SECTION */
.objectives-projects {
    background: #fff;
    padding-top: 60px;
    padding-bottom: 60px;
}

.objectives-row {
    display: flex;
    flex-wrap: nowrap; /* prevent image wrapping */
    align-items: stretch; /* equal height columns */
    gap: 30px; /* space between image and content */
}

.objectives-col {
    flex: 1 1 50%;
}

.objectives-image-wrapper {
    height: 100%;
    max-height: 500px; /* limit image height */
    overflow: hidden;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.objectives-image-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

.objectives-content {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.section-title {
    font-size: 2rem;
    font-weight: 700;
    color: #1a1a1a;
    margin-bottom: 30px;
}

.objectives-list li {
    position: relative;
    padding-left: 60px;
    margin-bottom: 22px;
    font-size: 1.05rem;
    line-height: 1.6;
    transition: 0.3s ease;
}

.objectives-list li:hover {
    transform: translateX(5px);
    color: #0077b6;
}

.objective-icon {
    position: absolute;
    left: 0;
    top: 0;
    width: 42px;
    height: 42px;
    background: #0077b6;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 16px;
    transition: 0.3s ease;
}

.objectives-list li:hover .objective-icon {
    transform: scale(1.15);
    background: #0056b3;
}

/* RESPONSIVE */
@media (max-width: 992px) {
    .objectives-row {
        flex-wrap: wrap; /* allow stacking on smaller screens */
    }
    .objectives-col {
        flex: 1 1 100%;
    }
    .objectives-image-wrapper {
        max-height: none;
        height: auto;
    }
}

/* ==========================
   PROJECTS SECTION - PREMIUM
========================== */
.projects-section {
    background: linear-gradient(180deg, #f8fbff 0%, #ffffff 100%);
    padding-top: 80px;
    padding-bottom: 80px;
}

.projects-section .section-title {
    font-size: 2.25rem;
    font-weight: 700;
    color: #1a1a1a;
    margin-bottom: 20px;
}

.project-card {
    background: #fff;
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
}

.project-card::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(0,180,216,0.15), transparent 70%);
    transform: rotate(45deg);
    transition: all 0.5s ease;
    z-index: 0;
}

.project-card:hover::before {
    top: -60%;
    left: -60%;
}

.project-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.12);
}

.project-card .project-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #00b4d8, #0077b6);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 36px;
    margin: auto;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: transform 0.4s ease, box-shadow 0.4s ease;
    position: relative;
    z-index: 1;
}

.project-card:hover .project-icon {
    transform: scale(1.15);
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

.project-focus {
    display: inline-block;
    background: rgba(0,119,182,0.08);
    color: #0077b6;
    font-weight: 600;
    padding: 6px 12px;
    border-radius: 12px;
    font-size: 0.875rem;
}

.project-card h4, .project-card p {
    position: relative;
    z-index: 1;
}

.project-card a.btn-outline-primary {
    border: 2px solid #0077b6;
    color: #0077b6;
    transition: all 0.3s ease;
}

.project-card a.btn-outline-primary:hover {
    background: #0077b6;
    color: #fff;
    transform: translateY(-2px);
}

/* RESPONSIVE */
@media (max-width: 992px) {
    .projects-section {
        padding-top: 60px;
        padding-bottom: 60px;
    }
    .project-card .project-icon {
        width: 70px;
        height: 70px;
        font-size: 32px;
    }
}

@media (max-width: 576px) {
    .projects-section {
        padding-top: 40px;
        padding-bottom: 40px;
    }
    .project-focus {
        font-size: 0.8rem;
    }
}
</style>